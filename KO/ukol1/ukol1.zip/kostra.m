function st=kostra(A)
    G = zeros(size(A,1));
    for i=1:size(A,1)
        for j=(i+1):size(A,1)
            G(i,j) = ldist(A(i,:), A(j,:));
        end
    end

    g = graph(G);
    st = spanningtree(g);
    graphedit(st);
end