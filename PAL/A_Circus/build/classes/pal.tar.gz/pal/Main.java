package pal;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.Stack;

public class Main {

    private static int N, M;
    private static Node[] points;

    public static void main(String[] args) throws IOException {
        loadInput();
        findRegions();
        prepareRegions();
        //printScc();
        loopRegions();


        if(maxProfit > 0) {
            System.out.println(maxProfit);
        } else {
            System.out.println("0");
        }
    }

    private static void loadInput() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        // from forum
        N = 0;
        M = 0;
        int price = 0, profit = 0, k;
        String line;
        k = 0;
        line = br.readLine() + " ";      // add sentinel
        while (line.charAt(k) != ' ') { // get N
            N = N * 10 + line.charAt(k++) - 48;
        }
        while (line.charAt(++k) != ' ') {// get M
            M = M * 10 + line.charAt(k) - 48;
        }

        points = new Node[N];
        for (int i = 0; i < N; i++) {
            k = 0;
            price = 0;
            profit = 0;
            line = br.readLine() + " ";      // add sentinel
            while (line.charAt(k) != ' ') { // get price
                price = price * 10 + line.charAt(k++) - 48;
            }
            if (k != line.length() - 1) {
                while (line.charAt(++k) != ' ') { // get profit
                    profit = profit * 10 + line.charAt(k) - 48;
                }
            }
            points[i] = new Node(i, price, profit);
        }

        int from, to;
        for (int i = 0; i < M; i++) {
            k = 0;
            from = 0;
            to = 0;
            line = br.readLine() + " ";      // add sentinel
            while (line.charAt(k) != ' ') { // get from
                from = from * 10 + line.charAt(k++) - 48;
            }
            while (line.charAt(++k) != ' ') { // get to
                to = to * 10 + line.charAt(k) - 48;
            }
            points[from - 1].addNeighbour(points[to - 1]);
        }
    }
    private static List<Region> scc;
    private static Stack s;

    private static void findRegions() {
        s = new Stack();
        scc = new ArrayList<Region>(); // list of strongly connected components
        for (int i = 0; i < N; i++) {
            if (points[i].label == -1) {
                tarjanAlgorithm(points[i]);
            }
        }
    }
    private static int tIndex = 0;
    private static int topoIndex = 0;
    /*
     * Tarjanuv algoritmus
     * @param node zpracovavany uzel
     * @param SCC seznam komponent (seznamu uzlu v komponentach)
     * @param s zasobnik
     */

    private static void tarjanAlgorithm(Node node) {
        node.label = tIndex;
        node.lowlink = tIndex;
        tIndex++;

        s.push(node); //pridej na zasobnik
        //printStack(s);
        for (Node neighbour : node.getNeighbours()) {
            if (neighbour.label == -1) {
                tarjanAlgorithm(neighbour);
                node.lowlink = node.lowlink < neighbour.lowlink ? node.lowlink : neighbour.lowlink;
            } else if (s.contains(neighbour)) {
                node.lowlink = node.lowlink < neighbour.lowlink ? node.lowlink : neighbour.lowlink;
            }

        }

        if (node.lowlink == node.label) { //pokud jsme v koreni komponenty
            Node n = null;
            Region component = new Region(topoIndex++); //seznam uzlu dane komponenty
            do {
                n = (Node) s.pop(); //vyber uzel ze zasobniku
                component.add(n); //pridej ho do komponenty
            } while (n.index != node.index); //dokud nejsme v koreni
            scc.add(component); //komponentu pridej do seznamu komponent
        }
    }

    private static void printScc() {
        System.err.println("SCCs");
        for (Region cmp : scc) {
            System.err.println("CMP: " + cmp.index);
            for (Node n : cmp.nodes) {
                System.err.println(" Node " + n.index + " label:" + n.label + " lowlink:" + n.lowlink + " rank: "+n.printRank());
            }
        }
    }


    private static void printStack(Stack<Node> s) {
        System.err.println("Stack s:");
        for (Node n : s) {
            System.err.println("  Node " + n.index);
        }
    }

    private static void prepareRegions() {
        for(Region r : scc) {
            for(Node n : r.nodes) {
                n.prepareRanks(r.nodeIndex-2);
            }
        }
    }
    private static void loopRegions() {
        ListIterator li = scc.listIterator(scc.size());
//        System.err.println("Num of regions: "+scc.size());
        int i = 1;
        // Iterate in reverse.
        while (li.hasPrevious()) {
            Region r  = (Region) li.previous();
            r.searchRegion();
//            System.err.println("Done region "+ (i++) + " out of "+scc.size());
        }
    }

    static int maxProfit = 0;
}
