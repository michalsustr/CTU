/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pal;

/**
 *
 * @author michal
 */
public class OpenItem {
    public Node current;
    public Node prev;
    public Node town1;
    public Node town2;
    public int numTowns;
    public int rankIndex;
    public static int wave = 0;
    public int depth;
    public boolean in;

    public OpenItem(Node current, Node prev, Node town1, Node town2, boolean in, int depth) {
        wave++;
        this.current = current;
        this.prev = prev;
        this.town1 = town1;
        this.town2 = town2;
        this.numTowns = 0;
        this.depth = depth;
        this.in = in;
        if(town1 != null) this.numTowns++;
        if(town2 != null) this.numTowns++;
        this.rankIndex = this.numTowns == 1 ? town1.regionIndex :
                this.numTowns == 2 ? 1 : 0;
    }

    void play() {
        // play the town
        if(numTowns == 0) {
            assert this.town1 == null;
            this.town1 = current;

            System.err.println("==");
            System.err.println("Playing town "+current.index);
            System.err.println(this);


            current.propagateRank(this);
            System.err.println("Rank: "+current.printRank());
//        System.err.println("Propageted: "+current.printRank());
            rankIndex = current.regionIndex;
            numTowns = 1;
            current.playTown(rankIndex);
            current.payPrice(rankIndex);
            System.err.println("Played: "+current.printRank());
            System.err.println("/==");
        } else {
            assert numTowns == 1;
            assert this.town2 == null;
            this.town2 = current;


            if(town1.rank[rankIndex]-current.price+current.profit > current.rank[1]) {
                System.err.println("==");
                System.err.println("Playing town "+current.index);
                System.err.println(this);

                current.propagateRank(this);
                numTowns = 2;
                rankIndex = 1;
                current.playTown(rankIndex);
                current.payPrice(rankIndex);

                System.err.println("Rank: "+current.printRank());
                System.err.println("Played: "+current.printRank());
                System.err.println("/==");

            }
        }


        // there is no need for investigation of towns, we have found first one
        if(in) {
            current.region.addInvestigationOfTowns = false;
        }

        // update max rank
        int maxRank = current.maxRank();
        if (maxRank > Main.maxProfit) {
            Main.maxProfit = maxRank;
            System.err.println("New max"+maxRank);
        }
    }

    void pass() {
        current.payPrice(rankIndex);
    }

    @Override
    public String toString() {
        int town1 = -1;
        if(this.town1 != null) {
            town1 = this.town1.index;
        }
        int town2 = -1;
        if(this.town2 != null) {
            town2 = this.town2.index;
        }
        return "Depth: "+depth+"\n"+
               "\t[c=" + current.index + "\tt1=" + town1 + "\tt2=" + town2 + "\tn=" + numTowns + "\tr=" + rankIndex + "]\n"+
               "\t{r: "+current.printRank()+"}";
    }



}
