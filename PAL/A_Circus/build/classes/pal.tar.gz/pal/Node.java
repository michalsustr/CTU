/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pal;

import java.util.ArrayList;
import java.util.TreeSet;

/**
 *
 * @author michal
 */
public class Node {
    private ArrayList<Node> neighbours;
    public int index; // from input
    public int price = 0, profit = 0;
    public int label = -1; // for tarjan
    public int lowlink; // for tarjan
    public Region region;
    // 0 for no visited town, 1 for two visited towns, others for 1 visited town and its index
    public int[] rank;
    public int regionIndex; // index for region

    public Node(int index, int price, int profit) {
        this.index = index;
        this.price = price;
        this.profit = profit;
        this.neighbours = new ArrayList<Node>();
    }

    public void prepareRanks(int regionTowns) {
        rank = new int[regionTowns+2];
        for (int i = 0; i < regionTowns+2; i++) {
            rank[i] = Integer.MIN_VALUE;
        }
    }

    public boolean isTown() {
        return this.profit != 0;
    }

    public void playTown(int rankIndex) {
        this.rank[rankIndex] = this.rank[rankIndex] == Integer.MIN_VALUE
                    ? (this.profit)
                    : (this.rank[rankIndex] + this.profit);
    }

    public void payPrice(int rankIndex) {
        this.rank[rankIndex] = this.rank[rankIndex] == Integer.MIN_VALUE
                    ? (-this.price)
                    : (this.rank[rankIndex] - this.price);
    }

    public int maxRank() {
        Integer max = Integer.MIN_VALUE;
        for (int i = 0; i < rank.length; i++) {
            if(rank[i] > max) {
                max = rank[i];
            }
        }
        return max;
    }

    public void addNeighbour(Node n) {
        neighbours.add(n);
    }

    public ArrayList<Node> getNeighbours() {
        return neighbours;
    }

    boolean isProfitable() {
        return profit > price;
    }

    void propagateRank(OpenItem item) {
        // nothing to propagate
        if(rank[item.rankIndex] == Integer.MIN_VALUE) {
            return;
        }
        if(item.numTowns == 2) {
            return;
        }

        if(item.numTowns == 0) {
            if(rank[item.town1.regionIndex] == Integer.MIN_VALUE) {
                rank[item.town1.regionIndex] = rank[0];
                return;
            }
            if(rank[item.town1.regionIndex] < rank[0]) {
               rank[item.town1.regionIndex] = rank[0];
            }
        }
        if(item.numTowns == 1) {
            if(rank[1] == Integer.MIN_VALUE) {
                rank[1] = rank[item.town1.regionIndex];
                return;
            }
            if(rank[1] < rank[item.town1.regionIndex]) {
               rank[1] = rank[item.town1.regionIndex];
            }
        }
    }

    public String printRank() {
        String ret = "";
        for (int i = 0; i < rank.length; i++) {
            ret = ret+"\t"+ (rank[i] == Integer.MIN_VALUE ? "-" : rank[i]);
        }
        return ret;
    }
}
