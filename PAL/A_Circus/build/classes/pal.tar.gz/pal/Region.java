/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author michal
 */
public class Region {

    public ArrayList<Node> nodes;
    public ArrayList<Node> towns;
    public int index;
    public int nodeIndex = 2; // so that we skip the first two values in ranks

    public Region(int index) {
        this.index = index;
        nodes = new ArrayList<Node>();
        towns = new ArrayList<Node>();
        open = new LinkedList<OpenItem>();
    }

    public void add(Node n) {
        nodes.add(n);
        n.region = this;
        if (n.isTown()) {
            n.regionIndex = nodeIndex++;
            towns.add(n);
        }
    }

    public boolean isProfitable() {
        boolean profitable = false;
        for (Node town : towns) {
            if (town.isProfitable()) {
                profitable = true;
            }
        }
        return profitable;
    }

    LinkedList<OpenItem> open;
    boolean addInvestigationOfTowns = true;
    static int localDepth = 0;
    public void searchRegion() {
        // if there are no starting nodes, open with towns
        if (open.size() == 0) {
            for (Node t : towns) {
                open.addLast(new OpenItem(t,null,null,null, false, 0));
            }
            addInvestigationOfTowns = false;
        }
        System.err.println("-----------------------------");
        System.err.println("Region "+index+ " with nodes:");
        for(Node n : nodes) {
            System.err.println("  #"+n.regionIndex+" has index "+n.index);
        }
        System.err.println("Start nodes:");
        for(OpenItem i : open) {
            System.err.println("  "+i.current.index+" with rank "+(i.current.rank[0] == Integer.MIN_VALUE ? "-" : i.current.rank[0]));
        }

        while(!open.isEmpty()) {
            OpenItem i = open.poll();
            Node current = i.current;
            int numTowns = i.numTowns;

            if(i.depth > localDepth) {
                localDepth = i.depth;
                System.err.println("----");
            }

            boolean canInvestigatePassingTown = true;
            boolean doingSmthInTown = false;

            // stop from propagating
            if(numTowns == 2 && current.rank[1] != Integer.MIN_VALUE && current.rank[1] < 0) {
                assert 0 != 1;
                continue;
            }

            if (current.isTown() && numTowns < 2) {
                // make sure that town1 would not become also town2, we don't pass the same town twice to play!
                if (i.town1 == null || (i.town1 != null && i.town1.index != current.index)) {

                    if (numTowns == 0) {
                        if(current.rank[0] != Integer.MIN_VALUE) {
                            // restart playing
                            if(current.rank[0] < 0) {
                                assert 0 == 1;
                                System.err.println("Restart playing");
                                current.rank[0] = 0;
                                canInvestigatePassingTown = false;
                            }
                        } else {
                            canInvestigatePassingTown = false;
                        }

                    }

                    // play the town
                    doingSmthInTown = true;
                    System.err.println("Playing town "+i.current.index);
                    // new wave
                    OpenItem passOpenItem = new OpenItem(i.current, i.prev, i.town1, i.town2, i.in, i.depth);
                    passOpenItem.play();
                    bfsNeighbours(passOpenItem);

                    // pass the town
                    if(canInvestigatePassingTown) {
                        if(current.rank[i.rankIndex]-current.price > 0
                           && i.prev.rank[i.rankIndex]-current.price > current.rank[i.rankIndex]) {
                            System.err.println("Passing town "+i.current.index);
                            System.err.println("  Prev rank: "+i.prev.rank[i.rankIndex]+" Curr rank"+current.rank[i.rankIndex]+ " Price"+current.price+" Profit:"+current.profit);
                            System.err.println("  Passing rank "+i.current.printRank()+" rankIndex"+i.rankIndex);
                            doingSmthInTown = true;

                            i.pass();
                            bfsNeighbours(i);
                        }
                    }


                }
            } else {
                // pass the village or town if rankIndex == 2
                if(current.rank[i.rankIndex]-current.price > 0
                    || (current.isTown() && i.prev.rank[i.rankIndex]-current.price > current.rank[i.rankIndex])) {
                    doingSmthInTown = true;
                    System.err.println("Passing node "+i.current.index);
                    i.pass();
                    bfsNeighbours(i);
                } else {
                    System.err.println("");
                    System.err.println("That's why :-)");
                }
            }
            if(!doingSmthInTown) {
                System.err.println("Not doing anything in "+i.current.index);
            }

            System.err.println("Current: "+i);

            System.err.println("");

            if(open.isEmpty() && addInvestigationOfTowns) {
                addInvestigationOfTowns = false;
                System.err.println("Restarting region with towns");
                for (Node t : towns) {
                    System.err.println("  "+t.index);
                    open.addLast(new OpenItem(t,null,null,null, false, 0));
                }
            }
        }
    }

    private void bfsNeighbours(OpenItem i) {
        // expand to other nodes
        Node current = i.current;
        assert current.rank[i.rankIndex] != Integer.MIN_VALUE;
        for (Node next : current.getNeighbours()) {
            // an edge going from this region to the next one
            // if the rank is positive, set it to the new region
            if (next.region.index != current.region.index) {
                System.err.println("Propagating to region "+next.region.index+" to node "+next.index+" with rank "+current.rank[i.rankIndex]);
                if (next.rank[0] == Integer.MIN_VALUE
                    || (!next.isTown() && next.rank[0] != Integer.MIN_VALUE
                        && current.rank[i.rankIndex]-next.price > next.rank[0])
                    // anything to town
                    || (next.isTown() && next.rank[0] != Integer.MIN_VALUE
                        && current.rank[i.rankIndex]-next.price+next.profit > next.rank[0])
                     ) {
                    if(next.rank[0] == Integer.MIN_VALUE) {
                        next.region.open.addLast(new OpenItem(next, current, null, null, true, i.depth+1));
                    }
                    next.rank[0] = current.rank[i.rankIndex];
                }
            } else {
                if(next.rank[i.rankIndex] == Integer.MIN_VALUE) {
                    if(next.isTown() && current.rank[i.rankIndex]-next.price+next.profit < 0) continue;
                    if(!next.isTown() && current.rank[i.rankIndex]-next.price < 0) continue;
                }

                if (
                    // anything to village
                    (next.rank[i.rankIndex] == Integer.MIN_VALUE)
                    || (!next.isTown() && next.rank[i.rankIndex] != Integer.MIN_VALUE
                        && current.rank[i.rankIndex]-next.price > next.rank[i.rankIndex])
                    // anything to town
                    || (next.isTown() && next.rank[i.rankIndex] != Integer.MIN_VALUE
                        && current.rank[i.rankIndex]-next.price+next.profit > next.rank[i.rankIndex])
                     ) {
//                    System.err.println(depth+" New search");
                    next.rank[i.rankIndex] = current.rank[i.rankIndex];
                    open.addLast(new OpenItem(next, current, i.town1, i.town2, i.in, i.depth+1));
                }
            }
        }
    }

    private void printRegion() {
        System.err.println("## Region " + index);
        for (Node n : nodes) {
            System.err.println("->Node " + n.index + " label:" + n.label + " lowlink:" + n.lowlink + " rank: " + n.rank);
        }

    }
}
