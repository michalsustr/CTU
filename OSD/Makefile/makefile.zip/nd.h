#ifndef __ND_H__
#define __ND_H__

extern int nd(int a);  // nejvetsi delitel cisla a

#endif
