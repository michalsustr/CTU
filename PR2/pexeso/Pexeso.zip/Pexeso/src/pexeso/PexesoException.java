/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package pexeso;

/**
 *
 * @author michal
 */
class PexesoException extends Exception {

	public PexesoException(String string) {
		super(string);
	}

}
