package kui;

import java.util.List;

public class AStar extends InformedSearchingAlgorithm {

    public List<Node> findWay(Node startNode, Node endNode) {
        startNode.expand();
        return null;
    }
}
