package kui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class BFS extends BlindSearchingAlgorithm {

    public List<Node> findWay(Node startNode) {
		Node current, next, track = null;
		// list of nodes that have to be investigated
		LinkedList<Node> open   = new LinkedList<Node>();
		// list of closed nodes to prevent recursion
		LinkedList<Node> closed = new LinkedList<Node>();

		List<Node> expand = null;

		// store hierarchy of nodes to backtrack the route
		// map is in form <child, parent>
		HashMap<Node, Node> hierarchy = new HashMap<Node, Node>();
		// the way to return
		LinkedList<Node> way = new LinkedList<Node>();

		// prevent recursion
		int cycle = 0;

		// starting node = end node
		if(startNode.isTarget()) {
			return null;
		}

		// start open list with start node
		open.add(startNode);

		while(!open.isEmpty()) {
			// take the first node from open
			current = open.poll();

			// this node has not been investigated yet (prevents recursion)
			if(!closed.contains(current)) {
				expand = current.expand();

				closed.add(current);
				Iterator<Node> it = expand.iterator();
				while(it.hasNext()) {
					next = it.next();
					if(!hierarchy.containsKey(next)) {
						hierarchy.put(next, current);
					}
					// target has been found
					if(next.isTarget()) {
						// backtrack the tree
						track = next;
						way.add(track);
						
						while(!track.equals(startNode)) {
							track = hierarchy.get(track);
							way.push(track);
						}
						return way;
					} else {
						open.addLast(next);
					}
				}
			}

			cycle++;
			if(cycle > 1E8) {
				System.err.println("too many cycles, ending");
				break;
			}
		}

		// could not find the way
		return null;
    }
}
