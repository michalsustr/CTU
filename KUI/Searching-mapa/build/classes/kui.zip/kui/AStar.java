package kui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AStar extends InformedSearchingAlgorithm {

    public List<Node> findWay(Node startNode, Node endNode) {
        Node current, next, track = null;
		Iterator<Node> it = null;
		// list of nodes that have to be investigated
		// the value determines the cost that is needed to get to this node
		// from the starting one
		HashMap<Node, Double> open = new HashMap<Node, Double>();
		// list of closed nodes (nodes that have been already expanded)
		// to prevent recursion
		LinkedList<Node> closed = new LinkedList<Node>();

		List<Node> expand = null;

		// store hierarchy of nodes to backtrack the route
		// map is in form <child, parent>
		HashMap<Node, Node> hierarchy = new HashMap<Node, Node>();
		// the way to return
		LinkedList<Node> way = new LinkedList<Node>();

		// prevent recursion
		int cycle = 0;
		double minValue; Node minNode = null;
		double cost, currentCost;

		boolean addToHierarchy;
		
		// starting node = end node
		if(startNode.isTarget()) {
			return null;
		}

		// start open list with start node
		open.put(startNode, 0.);

		while(!open.isEmpty()) {
			// take the node with the least value of the f-function
			it = open.keySet().iterator();
			minValue = Double.MAX_VALUE;
			while(it.hasNext()) {
				next = it.next();
				// f = g + h
				cost = open.get(next) + Math.sqrt(Math.pow(next.getX()-endNode.getX(), 2) + Math.pow(next.getY()-endNode.getY(), 2));
				if(cost < minValue) {
					minValue = open.get(next);
					minNode = next;
				}
			}
			current = minNode;
			currentCost = open.get(current); // cost g

			closed.add(current);
			open.remove(current);

			// target has been found
			if(current.isTarget()) {
				// backtrack the tree
				track = current;
				way.add(track);

				while(!track.equals(startNode)) {
					track = hierarchy.get(track);
					way.push(track);
				}
				return way;
			}
			
			expand = current.expand();
			it = expand.iterator();
			while(it.hasNext()) {
				next = it.next();
				if(closed.contains(next)) {
					continue;
				}
				
				// value of g function
				cost = currentCost +
					Math.sqrt(Math.pow(next.getX()-current.getX(), 2)+ Math.pow(next.getY()-current.getY(), 2));
				
				addToHierarchy = true;
				if(!open.containsKey(next)) {
					open.put(next, cost);
				} else if(open.get(next) > cost) {
					open.put(next, cost);
				} else {
					addToHierarchy = false;
				}

				if(addToHierarchy) {
					hierarchy.put(next, current);
				}
			}

			cycle++;
			if(cycle > 1E8) {
				System.err.println("too many cycles, ending");
				break;
			}
		}

		// could not find the way
		return null;
    }
}
