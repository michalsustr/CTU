% Nastaveni parametru modelu stabilizovane zakladny
% 
% Autor: Zdenek Hurak
% Datum: 6.9.2008

%% Parametry motoru D-2910-(G) firmy MOOG z katalogu vyrobce
Tpk  = 60.0;    %   [oz-in]                 spickovy moment
Vp   = 26.0;    %   [V]                     napeti pri spickovem momentu
Ip   = 1.45;    %   [A]                     proud pri spickovem momentu
Kt   = 41;      %   [oz-in/A]               momentova citlivost
Ke   = 0.290;   %   [V/rad/s]               back emf
R   = 18.0;     %   [Ohm]                   odpor
L   = 6.0e-3;   %   [H]                     indukcnost
Jm   = 125e-4;  %   [oz-in-s^2]             moment setrvacnosti motoru
Tf   = 1.2;     %   [oz-in]                 treni (max.)
Km   = 9.80;    %   [oz-in/sqrt(W)]         konstanta motoru
nofp = 10;      %   []                      pocet polu
Tr   = 5.0;     %   [%]                     procentualni rozdil mezi prumernym a spickovym momentem
Ip   = 1.44;    %   [%]                     proud pri maximalnim zatizeni

b    = 0.000;   %   [?]                     just placeholder
%% Prevod do SI jednotek
g    = 9.80665;      %   [m/s^-2]
inch = 0.0254;      %   [m]
oz   = 0.02835;     %   [kg]
ozin = oz*inch;     %   [kg-m]
rad  = 360/2/pi;    %   [deg]               ale pozor, krome vizualizace prubehu nic neprevadet!!!
ozins2 = oz*inch*g; %   [kg-m^2]

Tpk  = Tpk*ozin;     %   [kg-m]
Tpk  = Tpk*g;        %   [N-m]
Kt   = Kt*ozin;      %   [kg-m/A]
Kt   = Kt*g;         %   [N-m/A]
Jm   = Jm*ozins2;    %   [kg-m^2] 
Jm   = Jm*g;         %   [N-m^2]
Tf   = Tf*ozin;      %   [kg-m]
Tf   = Tf*g;         %   [N-m]
Km   = Km*ozin;      %   [kg-m/sqrt(W)]
Km   = Km*g;         %   [N-m/sqrt(W)]

%% Z Greybox identifikace

J = 0.0455;
s2 = 0.0644;