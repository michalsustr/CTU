%% ==========================================================
Gw_EL = tf(Kt,[L*J (L*b+R*J) (R*b+Kt*Ke)]);

set(Gw_EL,'InputName','Napeti [V]');
set(Gw_EL,'OutputName','Inercialni uhlova rychlost [rad/s]');

figure(1)
bode(Gw_EL)
title('Prenos elevacniho zavesu z napeti na inercialni uhlovou rychlost')

%% ==========================================================

% nyni se musi navrhnout regulator Cw_EL pomoci sisotool 

Sw_EL = feedback(1,Cw_EL*Gw_EL)

figure(2)
bodemag(Sw_EL)
title('Citlivostni funkce - prenos z poruchy na vystupu na reg. chybu')

%% ==========================================================

t_test = linspace(1,10,1000);
p_test = sin(2*pi*1*t_test); % uhlova rychlost nosice, menici se na 2Hz, v radianech/s

figure(3)
lsim(Sw_EL,p_test,t_test)
xlabel('t [s]')
ylabel('\omega [rad/s]')
title('Odezva zpetnovazebni smycky na harmonicke ruseni na vystupu')

%% =======================================================

Uw_EL = feedback(C,Gw_EL);

figure(4)
lsim(Uw_EL,p_test,t_test)
xlabel('t [s]')
ylabel('U [V]')
title('Napeti coby odezva na harmonicke ruseni na vystupu')