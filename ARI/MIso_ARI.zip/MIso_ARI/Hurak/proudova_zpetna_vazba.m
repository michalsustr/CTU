%% Vytvoreni modelu
init_sim

Gi_EL = tf([J b],[L*J (L*b+R*J) (R*b+Kt*Ke)]);

set(Gi_EL,'InputName','Napeti [V]')
set(Gi_EL,'OutputName','Proud [A]')

Gi_EL_red = tf(1,[L R]); % the inertial dynamics assumed too slow to influence the current response 
set(Gi_EL_red,'InputName','Napeti [V]');
set(Gi_EL_red,'OutputName','Proud [A]');

Gi_EL_red2 = tf(1,R); % even the electric dynamics is neglected
set(Gi_EL_red2,'InputName','Napeti [V]');
set(Gi_EL_red2,'OutputName','Proud [A]');

figure(1)
bode(Gi_EL,Gi_EL_red,Gi_EL_red2)
title('Prenosy z napeti na proud pro plny a zjednodusene modely')

%% PI controller for the current feedback

% Tuned so that the BW is ~1000 Hz (Hbridge switching @ 20kHz, therefore go one order bellow) 

Ci_EL0 = tf([L R],[1 0]);% C0 = (Ls + R)/s = R * (L/Rs + 1)/s
Ki = 6000;
Ci_EL = Ki*Ci_EL0;        % C = K * (Ls + R)/s = K*R * (L/Rs + 1)/s

Li_EL = Gi_EL * Ci_EL; Li_EL = minreal(Li_EL,1e-4);
Ti_EL = feedback(Li_EL,1); Ti_EL = minreal(Ti_EL,1e-4);
Si_EL = feedback(1,Li_EL); Si_EL = minreal(Si_EL,1e-4);
Ui_EL = feedback(Ci_EL,Gi_EL); Ui_EL = minreal(Ui_EL,1e-3);

figure(2)
step(Ti_EL,0.005);
xlabel('t [s]')
ylabel('Proud [A]')
title('Odezva na skokovou zmenu v referencnim proudu')

figure(3)
bodemag(Ti_EL);
title('Frequencni charakteristika uzavrene proudove smycky')
grid on

%% PI controller for the velocity feedback

Tiw_EL = Ti_EL* tf(Kt,[J 0]);
set(Tiw_EL,'InputName','Ref. current [A]');
set(Tiw_EL,'OutputName','Angular rate [rad/s]');

figure(4)
bode(Tiw_EL)
title('Prenos z proudu na uhlovou rychlost pri uzavrene proudove smycce')

Tiw_EL = Ti_EL*tf(Kt,[J 0]); % prenos z referencniho proudu na uhlovou rychlost

% Ted se musi navrhnout PI regulator, aby sirka pasma byla asi malo par desitek Hz (dekadu pod sirkou pasma proudove smycky)

% Cw_EL = ;

Lw_EL = Tiw_EL * Cw_EL; 
Tw_EL = feedback(Lw_EL,1); Tw_EL = minreal(Tw_EL,1e-5)
Sw_EL = feedback(1,Lw_EL); Sw_EL = minreal(Sw_EL,1e-5)
Uw_EL = feedback(Cw_EL,Tiw_EL); Uw_EL = minreal(Uw_EL,1e-5)

figure(5)
step(Tw_EL);
ylabel('Prenos z referencni na skutecnou uhlovou rychlost')

figure(6)
bode(Tw_EL);

%% PI Controller for the position feedback

Twt_EL = Tw_EL*tf(1,[1 0]); % prenos z referencni uhlove rychlosti na uhel (temer idealni integrator)
set(Twt_EL,'InputName','Ref. angular rate [rad/s]');
set(Twt_EL,'OutputName','Theta [rad]');

figure(7)
bode(Twt_EL)
title('Prenos z referencni uhlove rychlosti na polohu')

% nasleduje navrh regulatoru opet pomoc sisotool pro model Twt_EL. Sirka
% pasma asi desetiny Hz, kvuli pomalemu vzorkovani obrazu (jednotky Hz)