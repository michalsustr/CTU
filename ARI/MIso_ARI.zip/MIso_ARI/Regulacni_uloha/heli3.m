indA=find(sim.time==14)
indB=find(sim.time==19.3)
t=sim.time(indA:indB)-sim.time(indA);
u=sim.signals.values(indA:indB,1)
y=sim.signals.values(indA:indB,2)-sim.signals.values(indA,2)
plot(t,u,t,y)
%%

(0.1992-0.07031)/(19.27-18.87)
ans/0.06