syms omt omm alfat alfam betat betam gamat gamam deltat deltam bt bm Jt Jm mtz mmz ut um Km Kt
Ma=alfat*(omt*bt*Jt+mtz-ut*Kt)^2+betat*(omt*bt*Jt+mtz-ut*Kt)+alfam*(omm*bm*Jm+mmz-um*Km)^2+betam*(omm*bm*Jm+mmz-um*Km)
pretty(Ma)