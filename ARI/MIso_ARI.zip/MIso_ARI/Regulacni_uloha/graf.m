plot(scope1(:,1),scope1(:,3),scope1(:,1),scope1(:,2))
grid on
legend \phi_{azimuth} \phi_{elevation}
title('Step response: u_m(1)=0.435V; u_t(1)=-0.15V')
xlabel('time [s]')
ylabel('\phi normalaized in (-1, 1)')