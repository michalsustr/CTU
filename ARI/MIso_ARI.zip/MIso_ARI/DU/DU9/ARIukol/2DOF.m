a = s*(s-1);
b = s+2;
m = (s+2)*(s^2+5*s+4);

[x, y] = axbyc(a,b,m,'miny');
f = s^2;
[t, r]=axbyc(f,b,m,'miny');

%r = 5 + 4*s
%t = 2 + s
%x = 2 + s
%y = 5 + 5*s

T = coprime(b*r/m)

%T = 0.55 + 0.44s     /      0.55 + 0.44s + 0.11s^2

step(tf(T/s), tf(1/s), 5)