a = s*(s-1);
b=s+2;
m=(s+2)*(s^2+4*s+5)*(s+5);
f = s;

[x,q]=axbyc(a*f,b,m,'miny'),p=x*f

%x = 2 + s
%q = 25 + 25s + 10s^2
%p = 2s + s^2

T = q*coprime(b/m)
                                                      
%T = 25 + 25s + 10s^2     /      25 + 25s + 9s^2 + s^3

u = T/(b/a)
                                                                  
%u = -25s + 15s^3 + 10s^4     /      50 + 75s + 43s^2 + 11s^3 + s^4

