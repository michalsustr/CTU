%vypocet prvku Routhova pole
%          [a1  a3]
%       det[a2  a4]
%  b1=- -----------
%           a2
%
syms k
a1=274/3-7/21*k;
a2=3*k-150;
a3=269/3-8/21*k;
a4=0;

x=-det([1 a2;a1 a3])/a1