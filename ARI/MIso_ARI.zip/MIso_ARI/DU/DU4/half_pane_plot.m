%y = 0:0.1:10;
%plot(0*y,y)

t = 0:1:100;
t1 = -100:1:100;
a_1 = 1/3;
a_2 = 0.2;
b_1 = -300;
b_2 = 6;

%f_1 = inline('a_1*t-b_1');
f_2 = inline('a_2*t-b_2');

hold on,


plot(0*t1,t1,'g','LineWidth',2);
plot(t1,f_2(a_2,b_2,t1),'r','LineWidth',2);
plot([t;t],[f_1(a_1,b_1,t);f_1(a_2,b_2,t)],'b','LineWidth',2);
plot(t,f_1(a_1,b_1,t),'r','LineWidth',2);
plot(0*t1,t1,'g','LineWidth',2);
hold off,grid on

axis([-10 40 -10 40])
xlabel('K_I'),ylabel('K')
title('Oblast stability')
legend K>0 K>1/5K_I-6