t = 0:1:100;
a_1 = 3;
a_2 = 0.5;
b_1 = 1;
b_2 = 20;

f_1 = inline('a_1*t-b_1');
f_2 = inline('a_2*t-b_2');

hold on,
plot([t;t],[f_1(a_1,b_1,t);f_1(a_2,b_2,t)],'b','LineWidth',2);
plot(t,f_1(a_1,b_1,t),'r','LineWidth',2);
plot(t,f_2(a_2,b_2,t),'r','LineWidth',2);
hold off,grid on

xlabel('t'),ylabel('y(t)')
