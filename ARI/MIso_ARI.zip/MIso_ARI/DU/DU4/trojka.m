syms s
%L=(s+3)/(s-1)/(s+2)/(s+5)/(s+15)
num=[1 3];
expand((s-1)*(s+2)*(s+5)*(s+15))
den=[1 21 93 35 -150];
L=tf(num,den)
rlocus(-L)
