function sys = hw_4_st(dd, mm, yy, varargin)
%	Summary: 
%		Run this function with date of birth of the student and function will return homework assignment.
%
%	Syntax: sys = hw_4_st(dd, mm, yy, 'display',{true|false})
%
%	Inputs: 
%		required: 
%			date of birth (dd - day, mm - month, yy - year)
%		optional:
%			display - to display results
%
%	Outputs:
%		sys - system transfer function in zero-pole-gain format
%			
%	Author: 
%		Kamil Dolinsky (last modified 28.2.2011)

	[dd, mm, yy, display] = parseInput(dd, mm, yy, varargin{:});
	
	sys = zpk([],[-mm, -(6*(mm+round(dd/10)))],1);
	
	if display
		fprintf('Transfer function for assignment is \n')
		sys
	end
	
end

function [dd, mm, yy, display] = parseInput(dd, mm, yy, varargin)
	p = inputParser;
	p.addRequired('dd',@(x)isa(x,'numeric')&& size(x,1) == 1 && size(x,2) == 1 && x >= 1 && x <= 31 && mod(x,1) == 0);
	p.addRequired('mm',@(x)isa(x,'numeric')&& size(x,1) == 1 && size(x,2) == 1 && x >= 1 && x <= 12 && mod(x,1) == 0);
	p.addRequired('yy',@(x)isa(x,'numeric')&& size(x,1) == 1 && size(x,2) == 1 && x >= 0 && x <= 99 && mod(x,1) == 0);
	p.addOptional('display',nargout == 0,@(x)isa(x,'logical'));

	p.parse(dd, mm, yy, varargin{:});

	dd = p.Results.dd;
	mm = p.Results.mm;
	yy = p.Results.yy;
	display = p.Results.display;
end