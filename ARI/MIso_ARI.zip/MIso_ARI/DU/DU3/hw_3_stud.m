function [num_1,den_1,num_2,den_2] = hw_3_stud(dd, mm, yy)
%	Summary: 
%		Run this function with date of birth of the student and function will return homework assignement.
%
%	Syntax: [num_1,den_1,num_2,den_2] = hw_3_stud(dd, mm, yy)
%
%	Inputs: 
%		required: 
%			date of birth (dd - day, mm - month, yy - year)
%
%	Outputs:
%		num_1, den_1, num_2, den_2 - numerator and denumerator for first and second assignement
%		
%	Author: 
%		Kamil Dolinsky (last modified 21.2.2011)

	[dd, mm, yy] = parseInput(dd, mm, yy);
	[T,num,den] = get_parameters(dd,mm,yy);
	
	num_1 = 1;
	den_1 = [T 1];
	num_2 = num;
	den_2 = den;
	
end

function [dd, mm, yy] = parseInput(dd, mm, yy)
	p = inputParser;
	p.addRequired('dd',@(x)isa(x,'numeric')&& size(x,1) == 1 && size(x,2) == 1 && x >= 1 && x <= 31 && mod(x,1) == 0);
	p.addRequired('mm',@(x)isa(x,'numeric')&& size(x,1) == 1 && size(x,2) == 1 && x >= 1 && x <= 12 && mod(x,1) == 0);
	p.addRequired('yy',@(x)isa(x,'numeric')&& size(x,1) == 1 && size(x,2) == 1 && x >= 0 && x <= 99 && mod(x,1) == 0);

	p.parse(dd, mm, yy);

	dd = p.Results.dd;
	mm = p.Results.mm;
	yy = p.Results.yy;
end

function [T,num,den] = get_parameters(dd,mm,yy)
	dob = get_dob(dd,mm);
	
	T = dob/10;
	
	alpha = -(mod(dob+mm,7) + mod(dd,5) + 1)/(mod(dob+5,7) + 1);
	omega = mod(dob*3+mm,13) + mod(mm*5+dd*3+yy*2,7) + 1;
	
	den = poly([alpha-i*omega alpha+i*omega]);
	num = den(1,3);
end

function dob = get_dob(dd,mm)

	month = [31 28 31 30 31 30 31 31 30 31 30 31];

	if mm > 1
		dob = sum(month(1:mm-1)) + dd;
	else
		dob = dd;
	end
end