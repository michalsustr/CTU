P=tf(25,[1 1 0],-1)
[F,G,H,J]=tf2ss([0 0 25],[1 1 0])
pol=det(z*ones(2)-F)
K=[0 1]*inv(C0)*F^2
T1=ss(F-G*[-1 0],G,H,0,-1)
pole(T1)
step(T1)
stepinfo(T1)
step(T1/25, T1/25/25)
