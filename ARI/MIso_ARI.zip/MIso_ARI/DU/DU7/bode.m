%%
syms k
num=[1*1];
subs(num,k,1);
den=[1 170 6000 0];
OL=tf(num,den);
hold on
%[mag,phase,w]=bode(tf(num,den))
%subplot(2,2,1)
bode(OL)
grid on
title('Open-Loop Frequency Characteristic')
num=[1*199530];
OL=tf(num,den);
bode(OL)
legend K=1 K=199530
%%
%subplot(2,2,2)
%semilogx(w,phase)
subplot(2,2,3)
step(tf(num*den,1+num*den))
grid on
subplot(2,2,4)
nyquist(tf(num,den))
grid on