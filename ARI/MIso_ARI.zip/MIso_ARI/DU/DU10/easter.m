for n=0:90
rok=2011+n;
a=mod(rok,19);
b=mod(rok,4);
c=mod(rok,7);
m=24;
n=5;
d=mod((19*a+m),30);
e=mod((n+2*b+4*c+6*d),7);
u=d+e-9;
if (u==24) 
    rok 
end
end