sim('prvni')%reading simulink data to workspace
time=linspace(0,20,106);%creating time vector
plot(time, simout.signals.values)
grid on
title('Odezva regulovaneho systemu')
xlabel('time')
ylabel('f(t)')
