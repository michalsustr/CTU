%%
A=[-0.4 0 -0.02;1 0 0;-1.4 9.8 -0.01], B=[6.8;0;9.3], C=[0 0 1], D=[0]
heli=ss(A,B,C,D)%vytvorim state-space model z dodanych matic
zero(zpk(heli))%nuly systemu
pole(zpk(heli))%a poly systemu
syms s
pcl=(s+2)*(s+1+i)*(s+1-i)
pcl=expand(pcl)
pcl=vpa(pcl)
p=sym2poly(pcl)
p=roots(p)
K=place(A,B,p)
%%
pobs=(s+8)*(s+4+4*i*sqrt(3))*(s+4-4*i*sqrt(3))
pobs=expand(pobs)
pcobs=roots(sym2poly(pobs))
AA=A',BB=C',CC=B'
KK=place(AA,BB,pcobs)
L=KK'
%%
Areg=A-B*K-L*C
Fy=ss(Areg,L,-K,[0])
Fr=1-ss(Areg,B,K,[0])
pole(Fy)

%%
Frycelk=tf(heli)*tf(Fr)/(1-tf(heli)*tf(Fy))
Frycelk=coprime(tf(heli)*tf(Fr)/(1-tf(heli)*tf(Fy)))

%%
Acelk=[A-B*K,B*K;zeros(3,3),A-L*C]
Bcelk=[B;zeros(3,1)]
Ccelk=[C,zeros(1,3)]
Frycelk2=ss(Acelk,Bcelk,Ccelk,[0])




