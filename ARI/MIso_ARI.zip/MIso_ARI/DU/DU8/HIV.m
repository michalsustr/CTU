A=[-0.04167 0 -0.0058;0.0217 -0.24 0.0058;0 100 -2.4], B=[5.2;-5.2;0], C=[0 0 1], D=[0]
hiv=ss(A,B,C,D)%vytvorim state-space model z dodanych matic
zero(zpk(hiv))%nuly systemu
pole(zpk(hiv))%a poly systemu
pcl=(s+0.02)*(s^2+2*omegan*dzeta*s+omegan^2)
pcl=expand(pcl)
pcl=vpa(pcl)
p=sym2poly(pcl)
p=roots(p)
place(A,B,p)



Abig=[A,zeros(3,1);-C,0],Bbig=[B;0],Cbig=[C 0],Bref=[0;0;0;1]
pol=(s+100)*pcl
pol=sym2poly(pol)
poles=roots(pol)
Kcelk=place(Abig,Bbig,ans)
T=ss((Abig-Bbig*Kcelk),Bref,Cbig,0)
pole(T)
step(T)
