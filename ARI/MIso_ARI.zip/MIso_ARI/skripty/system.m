A=[-0.45 0 -0.015;1 0 0;-1.4 9.8 -0.02];
B=[5.8;0;9.9];
C=[0 0 1];
D=0;
sys=ss(A,B,C,D)
pole(sys)
zero(sys)
ctrb(sys)
rank(ctrb(sys))
obsv(sys)
rank(obsv(sys))