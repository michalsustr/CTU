%%
%vypocet zpetnovazebniho vstupne-vystupniho regulatoru
tf(sys)
rlocus(sys)
%%
%vypocitam pozadavky
ts=25;%settling time
os=30;%overshoot
[omn, bw]=bandwidth(zeta(os),ts)
%%
rltool(sys)