function [omn, bw] = bandwidth(z,ts)
%Vraci sirku pasma systemu druheho radu, input parametry jsou tlumeni a settling time
%Ex: [omn, bw] = bandwidth(6,2)
   omn=4/z/ts;
   bw=omn*sqrt(1-2*z^2+sqrt(4*z^4-4*z^2+2));
end