syms s
a=s^3 + 0.47*s^2 - 0.012*s + 0.147;%jmenovatel systemu
b=9.9*s^2 - 3.665*s + 56.84;%citatel systemu
c=0;%pozadovany char polynom

%%
%ma-li sys sledovat rampu, pak f = s^2
[p,q]=axbyc(a,b,c,'miny');
[t,r]=axbyc(f,b,c,'miny');
T = coprime(b*r/c);
step(tf(T/s),tf(1/s),3);
%%
%vysledek
sys = tf(r) * feedback(tf(1/p*b/a),tf(q));
pole(sys);
step(sys/s,tf(1/s),5);
