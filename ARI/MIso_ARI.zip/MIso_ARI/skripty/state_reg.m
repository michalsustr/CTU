%%
%system
A=[-0.4 0 -0.02;1 0 0;-1.4 9.8 -0.01], B=[6.8;0;9.3], C=[0 0 1], D=[0]
sys=ss(A,B,C,D)%vytvorim state-space model z dodanych matic
zero(sys)%nuly systemu
pole(sys)%a poly systemu
%%
%stavova zpetna vazba
syms s
%pcl=(s+2)*(s+1+i)*(s+1-i)
pcl=(s^2+2*0.5912*1.1276*s+1.1276^2)*(s+10)
pcl=expand(pcl)
pcl=vpa(pcl)
p=sym2poly(pcl)
p=roots(p)
K=place(A,B,p)
%%
%system s integratorem
Abig=[A,zeros(3,1);-C,0],Bbig=[B;0],Cbig=[C 0],Bref=[0;0;0;1]%matice velkeho systemu
pol=(s+100)*pcl%puvodni polynom s mnou vhodne zvolenym
pol=sym2poly(pol)%zbavim se symbolicke promenne
poles=roots(pol)%koreny..
Kcelk=place(Abig,Bbig,poles)%implementace Ackermannova vzorce
T=ss((Abig-Bbig*Kcelk),Bref,Cbig,0)%stavovy popis systemu
pole(T)%overeni polu
step(T)%vykresleni
%%
%pozorovatel
pobs=(s^2+2*0.5912*1.1276*s+1.1276^2)*(s+10)
pobs=expand(pobs)
pcobs=roots(sym2poly(pobs))
AA=A',BB=C',CC=B'
KK=place(AA,BB,pcobs)
L=KK'
%%
%?
Areg=A-B*K-L*C
Fy=ss(Areg,L,-K,[0])
Fr=1-ss(Areg,B,K,[0])
pole(Fy)

%%
%?
Frycelk=tf(sys)*tf(Fr)/(1-tf(heli)*tf(Fy))
Frycelk=coprime(tf(sys)*tf(Fr)/(1-tf(heli)*tf(Fy)))

%%
%system s pozorovatelem
Acelk=[A-B*K,B*K;zeros(3,3),A-L*C]
Bcelk=[B;zeros(3,1)]
Ccelk=[C,zeros(1,3)]
Frycelk2=ss(Acelk,Bcelk,Ccelk,[0])
step(Frycelk2/4.47)



