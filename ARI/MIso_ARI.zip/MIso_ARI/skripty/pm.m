function [pm]=pm(z)
%pocita phase margin z tlumeni
pm=atand(2*z/sqrt(-2*z^2+sqrt(1+4*z^4)));
end
