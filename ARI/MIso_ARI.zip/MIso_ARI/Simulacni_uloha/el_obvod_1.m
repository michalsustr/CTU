%This file will, after execution, run simulation in simulink model of
%circuit and plot outputs of original and linear system responses on given
%input. Should you be interested in different initial conditions or input
%signals, please open the .mdl file and change parameters, then execute
%this file again.
sim('elektricky_obvod_1')%reading simulink data to workspace
time=linspace(0,75,length(simout.signals.values));%creating time vector
plot(time, simout.signals.values)
grid on
title('Comparison of linearized and original model')
xlabel('time[s]')
ylabel('current through inductor i_L(t)[V]')
legend original linearized