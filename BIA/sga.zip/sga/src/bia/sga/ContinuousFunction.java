package bia.sga;

/**
 * Created by drchajan on 18/03/14.
 */
public interface ContinuousFunction {
    double f(double[] x);

    int getDimension();
}
